import type { Metadata } from "next";
import { Inter, Outfit, JetBrains_Mono } from "next/font/google";
import AppProviders from "@/components/providers/AppProviders";
import { getPublicSettings } from "@/lib/getPublicSettings";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const outfit = Outfit({
  subsets: ["latin"],
  variable: "--font-outfit",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
});

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getPublicSettings();
  const { seo, branding } = settings;
  const keywords = seo.keywords
    .split(",")
    .map((k) => k.trim())
    .filter(Boolean);

  return {
    title: seo.metaTitle,
    description: seo.metaDescription,
    keywords,
    authors: [{ name: branding.siteName }],
    robots: seo.robots,
    ...(seo.canonicalUrl ? { alternates: { canonical: seo.canonicalUrl } } : {}),
    openGraph: {
      title: seo.ogTitle || seo.metaTitle,
      description: seo.ogDescription || seo.metaDescription,
      type: "website",
      locale: "en_US",
      siteName: branding.siteName,
      ...(seo.ogImage ? { images: [{ url: seo.ogImage }] } : {}),
    },
    twitter: {
      card: (seo.twitterCard as "summary" | "summary_large_image") || "summary_large_image",
      title: seo.ogTitle || seo.metaTitle,
      description: seo.ogDescription || seo.metaDescription,
      ...(seo.twitterSite ? { site: seo.twitterSite } : {}),
      ...(seo.ogImage ? { images: [seo.ogImage] } : {}),
    },
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const initialSettings = await getPublicSettings();

  return (
    <html
      lang={initialSettings.general.defaultLang || "en"}
      className={`dark ${inter.variable} ${outfit.variable} ${jetbrains.variable}`}
      suppressHydrationWarning
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                try {
                  var stored = localStorage.getItem('infinicast-theme');
                  if (stored) {
                    var parsed = JSON.parse(stored);
                    var theme = parsed && parsed.state && parsed.state.theme;
                    if (theme === 'light') {
                      document.documentElement.classList.remove('dark');
                      document.documentElement.classList.add('light');
                    }
                  }
                } catch(e) {}
              })();
            `,
          }}
        />
      </head>
      <body className="bg-[var(--bg-primary)] text-[var(--text-secondary)] antialiased noise-overlay">
        <AppProviders initialSettings={initialSettings}>{children}</AppProviders>
      </body>
    </html>
  );
}