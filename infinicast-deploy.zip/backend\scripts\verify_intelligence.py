"""Verify intelligence platform endpoints and core flows."""

import sys
import uuid

import httpx

BASE = "http://127.0.0.1:8000"
ADMIN_EMAIL = "admin@inflationplatform.com"
ADMIN_PASSWORD = "Admin123!"


def login(client: httpx.Client) -> str:
    r = client.post("/api/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    if r.status_code != 200:
        raise RuntimeError(f"Login failed: {r.status_code} {r.text}")
    return r.json()["access_token"]


def check(name: str, r: httpx.Response, expected: set[int] | None = None) -> None:
    ok = expected or {200, 201}
    if r.status_code not in ok:
        raise RuntimeError(f"{name}: {r.status_code} {r.text[:500]}")


def main() -> int:
    errors: list[str] = []
    client = httpx.Client(base_url=BASE, timeout=30.0)

    try:
        token = login(client)
        h = {"Authorization": f"Bearer {token}"}
        print("✓ Auth login")

        # Health
        check("health", client.get("/health"))
        print("✓ Health")

        # Intelligence read endpoints
        endpoints = [
            ("events", client.get("/api/intelligence/events", headers=h)),
            ("events timeline", client.get("/api/intelligence/events/timeline/NG", headers=h)),
            ("accuracy", client.get("/api/intelligence/accuracy", headers=h)),
            ("risk NG", client.get("/api/intelligence/risk/NG", headers=h)),
            ("risk list", client.get("/api/intelligence/risk", headers=h)),
            ("health NG", client.get("/api/intelligence/health/NG", headers=h)),
            ("news", client.get("/api/intelligence/news", headers=h)),
            ("sentiment NG", client.get("/api/intelligence/sentiment/NG", headers=h)),
            ("indicators NG", client.get("/api/intelligence/indicators/NG", headers=h)),
            ("multi-horizon NG", client.get("/api/intelligence/multi-horizon/NG", headers=h)),
            ("research", client.get("/api/intelligence/research", headers=h)),
            ("scenarios", client.get("/api/intelligence/scenarios", headers=h)),
            ("admin settings", client.get("/api/admin/intelligence/settings", headers=h)),
            ("admin retraining", client.get("/api/admin/intelligence/retraining", headers=h)),
        ]
        for name, resp in endpoints:
            check(name, resp)
            print(f"✓ {name}")

        # Scenario simulation
        sc = client.post(
            "/api/intelligence/scenarios",
            headers=h,
            json={"country_code": "NG", "name": "Test Scenario", "overrides": {"interest_rate": 20}},
        )
        check("run scenario", sc, {200, 201})
        print("✓ run scenario")

        # Resolve live cached FX for NG (fallback to feature-range midpoint)
        fx_resp = client.get("/api/exchange-rates/NG", headers=h)
        ng_exchange_rate = 1000.25
        if fx_resp.status_code == 200:
            cached = fx_resp.json().get("exchange_rate")
            if isinstance(cached, (int, float)) and cached > 0:
                ng_exchange_rate = float(cached)

        # Forecast with TS-Transformer
        fc = client.post(
            "/api/predictions/forecast",
            headers=h,
            json={
                "country_code": "NG",
                "forecast_horizon": 6,
                "input_data": {
                    "cpi": 285, "gdp_growth": 3.2, "interest_rate": 27.5,
                    "exchange_rate": ng_exchange_rate, "oil_price": 82, "gov_spending": 18.5,
                    "employment_rate": 94.8, "unemployment_rate": 5.2,
                    "money_supply": 65000, "trade_balance": -15,
                },
            },
        )
        check("forecast", fc, {200, 201})
        pred = fc.json()
        pred_id = pred["id"]
        assert pred.get("explainability"), "Missing explainability"
        assert pred.get("multi_horizon"), "Missing multi_horizon"
        assert pred.get("confidence_bands"), "Missing confidence_bands"
        print(f"✓ forecast (id={pred_id[:8]}…)")

        # Explainability
        exp = client.get(f"/api/intelligence/explainability/{pred_id}", headers=h)
        check("explainability", exp)
        assert exp.json().get("feature_importance"), "Missing feature_importance"
        print("✓ explainability")

        # Admin create event
        ev = client.post(
            "/api/admin/intelligence/events",
            headers=h,
            json={
                "title": "Verification Test Event",
                "country": "NG",
                "category": "monetary_policy",
                "event_date": "2026-01-15",
                "severity_score": 5,
                "economic_impact_score": 6,
                "description": "Auto verification event",
            },
        )
        check("create event", ev, {200, 201})
        event_id = ev.json()["id"]
        print("✓ create event")

        # Delete event
        dl = client.delete(f"/api/admin/intelligence/events/{event_id}", headers=h)
        check("delete event", dl, {200, 204})
        print("✓ delete event")

        # Update settings
        us = client.put(
            "/api/admin/intelligence/settings",
            headers=h,
            json={"accuracy_threshold": 75, "sentiment_weight": 0.15},
        )
        check("update settings", us)
        print("✓ update settings")

        # Compare countries
        cmp = client.post(
            "/api/predictions/compare",
            headers=h,
            json={"country_codes": ["NG", "US"], "forecast_horizon": 3},
        )
        check("compare", cmp, {200, 201})
        print("✓ compare countries")

        print("\n✅ All intelligence verification checks passed.")
        return 0

    except Exception as exc:
        errors.append(str(exc))
        print(f"\n❌ FAILED: {exc}")
        return 1
    finally:
        client.close()


if __name__ == "__main__":
    sys.exit(main())