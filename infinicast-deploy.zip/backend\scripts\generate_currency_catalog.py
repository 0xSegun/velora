"""One-off generator for app/data/exchangerate_currencies.py"""
from pathlib import Path

ENTRIES = """AED|UAE Dirham|United Arab Emirates|AE|Asia|Middle East
AFN|Afghan Afghani|Afghanistan|AF|Asia|South Asia
ALL|Albanian Lek|Albania|AL|Europe|Southern Europe
AMD|Armenian Dram|Armenia|AM|Asia|Western Asia
ANG|Netherlands Antillian Guilder|Curaçao|CW|North America|Caribbean
AOA|Angolan Kwanza|Angola|AO|Africa|Central Africa
ARS|Argentine Peso|Argentina|AR|South America|South America
AUD|Australian Dollar|Australia|AU|Oceania|Oceania
AWG|Aruban Florin|Aruba|AW|North America|Caribbean
AZN|Azerbaijani Manat|Azerbaijan|AZ|Asia|Western Asia
BAM|Bosnia and Herzegovina Mark|Bosnia and Herzegovina|BA|Europe|Southern Europe
BBD|Barbados Dollar|Barbados|BB|North America|Caribbean
BDT|Bangladeshi Taka|Bangladesh|BD|Asia|South Asia
BGN|Bulgarian Lev|Bulgaria|BG|Europe|Eastern Europe
BHD|Bahraini Dinar|Bahrain|BH|Asia|Middle East
BIF|Burundian Franc|Burundi|BI|Africa|East Africa
BMD|Bermudian Dollar|Bermuda|BM|North America|North America
BND|Brunei Dollar|Brunei|BN|Asia|Southeast Asia
BOB|Bolivian Boliviano|Bolivia|BO|South America|South America
BRL|Brazilian Real|Brazil|BR|South America|South America
BSD|Bahamian Dollar|Bahamas|BS|North America|Caribbean
BTN|Bhutanese Ngultrum|Bhutan|BT|Asia|South Asia
BWP|Botswana Pula|Botswana|BW|Africa|Southern Africa
BYN|Belarusian Ruble|Belarus|BY|Europe|Eastern Europe
BZD|Belize Dollar|Belize|BZ|North America|Central America
CAD|Canadian Dollar|Canada|CA|North America|North America
CDF|Congolese Franc|Democratic Republic of the Congo|CD|Africa|Central Africa
CHF|Swiss Franc|Switzerland|CH|Europe|Western Europe
CLF|Chilean Unidad de Fomento|Chile|CL|South America|South America
CLP|Chilean Peso|Chile|CL|South America|South America
CNH|Offshore Chinese Renminbi|China|CN|Asia|East Asia
CNY|Chinese Renminbi|China|CN|Asia|East Asia
COP|Colombian Peso|Colombia|CO|South America|South America
CRC|Costa Rican Colon|Costa Rica|CR|North America|Central America
CUP|Cuban Peso|Cuba|CU|North America|Caribbean
CVE|Cape Verdean Escudo|Cape Verde|CV|Africa|West Africa
CZK|Czech Koruna|Czech Republic|CZ|Europe|Central Europe
DJF|Djiboutian Franc|Djibouti|DJ|Africa|East Africa
DKK|Danish Krone|Denmark|DK|Europe|Northern Europe
DOP|Dominican Peso|Dominican Republic|DO|North America|Caribbean
DZD|Algerian Dinar|Algeria|DZ|Africa|North Africa
EGP|Egyptian Pound|Egypt|EG|Africa|North Africa
ERN|Eritrean Nakfa|Eritrea|ER|Africa|East Africa
ETB|Ethiopian Birr|Ethiopia|ET|Africa|East Africa
EUR|Euro|European Union|EU|Europe|Western Europe
FJD|Fiji Dollar|Fiji|FJ|Oceania|Oceania
FKP|Falkland Islands Pound|Falkland Islands|FK|South America|South America
FOK|Faroese Króna|Faroe Islands|FO|Europe|Northern Europe
GBP|Pound Sterling|United Kingdom|GB|Europe|Western Europe
GEL|Georgian Lari|Georgia|GE|Asia|Western Asia
GGP|Guernsey Pound|Guernsey|GG|Europe|Western Europe
GHS|Ghanaian Cedi|Ghana|GH|Africa|West Africa
GIP|Gibraltar Pound|Gibraltar|GI|Europe|Southern Europe
GMD|Gambian Dalasi|The Gambia|GM|Africa|West Africa
GNF|Guinean Franc|Guinea|GN|Africa|West Africa
GTQ|Guatemalan Quetzal|Guatemala|GT|North America|Central America
GYD|Guyanese Dollar|Guyana|GY|South America|South America
HKD|Hong Kong Dollar|Hong Kong|HK|Asia|East Asia
HNL|Honduran Lempira|Honduras|HN|North America|Central America
HRK|Croatian Kuna|Croatia|HR|Europe|Southern Europe
HTG|Haitian Gourde|Haiti|HT|North America|Caribbean
HUF|Hungarian Forint|Hungary|HU|Europe|Central Europe
IDR|Indonesian Rupiah|Indonesia|ID|Asia|Southeast Asia
ILS|Israeli New Shekel|Israel|IL|Asia|Middle East
IMP|Manx Pound|Isle of Man|IM|Europe|Western Europe
INR|Indian Rupee|India|IN|Asia|South Asia
IQD|Iraqi Dinar|Iraq|IQ|Asia|Middle East
ISK|Icelandic Króna|Iceland|IS|Europe|Northern Europe
JEP|Jersey Pound|Jersey|JE|Europe|Western Europe
JMD|Jamaican Dollar|Jamaica|JM|North America|Caribbean
JOD|Jordanian Dinar|Jordan|JO|Asia|Middle East
JPY|Japanese Yen|Japan|JP|Asia|East Asia
KES|Kenyan Shilling|Kenya|KE|Africa|East Africa
KGS|Kyrgyzstani Som|Kyrgyzstan|KG|Asia|Central Asia
KHR|Cambodian Riel|Cambodia|KH|Asia|Southeast Asia
KID|Kiribati Dollar|Kiribati|KI|Oceania|Oceania
KMF|Comorian Franc|Comoros|KM|Africa|East Africa
KRW|South Korean Won|South Korea|KR|Asia|East Asia
KWD|Kuwaiti Dinar|Kuwait|KW|Asia|Middle East
KYD|Cayman Islands Dollar|Cayman Islands|KY|North America|Caribbean
KZT|Kazakhstani Tenge|Kazakhstan|KZ|Asia|Central Asia
LAK|Lao Kip|Laos|LA|Asia|Southeast Asia
LBP|Lebanese Pound|Lebanon|LB|Asia|Middle East
LKR|Sri Lanka Rupee|Sri Lanka|LK|Asia|South Asia
LRD|Liberian Dollar|Liberia|LR|Africa|West Africa
LSL|Lesotho Loti|Lesotho|LS|Africa|Southern Africa
LYD|Libyan Dinar|Libya|LY|Africa|North Africa
MAD|Moroccan Dirham|Morocco|MA|Africa|North Africa
MDL|Moldovan Leu|Moldova|MD|Europe|Eastern Europe
MGA|Malagasy Ariary|Madagascar|MG|Africa|East Africa
MKD|Macedonian Denar|North Macedonia|MK|Europe|Southern Europe
MMK|Burmese Kyat|Myanmar|MM|Asia|Southeast Asia
MNT|Mongolian Tögrög|Mongolia|MN|Asia|East Asia
MOP|Macanese Pataca|Macau|MO|Asia|East Asia
MRU|Mauritanian Ouguiya|Mauritania|MR|Africa|West Africa
MUR|Mauritian Rupee|Mauritius|MU|Africa|East Africa
MVR|Maldivian Rufiyaa|Maldives|MV|Asia|South Asia
MWK|Malawian Kwacha|Malawi|MW|Africa|East Africa
MXN|Mexican Peso|Mexico|MX|North America|North America
MYR|Malaysian Ringgit|Malaysia|MY|Asia|Southeast Asia
MZN|Mozambican Metical|Mozambique|MZ|Africa|East Africa
NAD|Namibian Dollar|Namibia|NA|Africa|Southern Africa
NGN|Nigerian Naira|Nigeria|NG|Africa|West Africa
NIO|Nicaraguan Córdoba|Nicaragua|NI|North America|Central America
NOK|Norwegian Krone|Norway|NO|Europe|Northern Europe
NPR|Nepalese Rupee|Nepal|NP|Asia|South Asia
NZD|New Zealand Dollar|New Zealand|NZ|Oceania|Oceania
OMR|Omani Rial|Oman|OM|Asia|Middle East
PAB|Panamanian Balboa|Panama|PA|North America|Central America
PEN|Peruvian Sol|Peru|PE|South America|South America
PGK|Papua New Guinean Kina|Papua New Guinea|PG|Oceania|Oceania
PHP|Philippine Peso|Philippines|PH|Asia|Southeast Asia
PKR|Pakistani Rupee|Pakistan|PK|Asia|South Asia
PLN|Polish Złoty|Poland|PL|Europe|Central Europe
PYG|Paraguayan Guaraní|Paraguay|PY|South America|South America
QAR|Qatari Riyal|Qatar|QA|Asia|Middle East
RON|Romanian Leu|Romania|RO|Europe|Eastern Europe
RSD|Serbian Dinar|Serbia|RS|Europe|Southern Europe
RUB|Russian Ruble|Russia|RU|Europe|Eastern Europe
RWF|Rwandan Franc|Rwanda|RW|Africa|East Africa
SAR|Saudi Riyal|Saudi Arabia|SA|Asia|Middle East
SBD|Solomon Islands Dollar|Solomon Islands|SB|Oceania|Oceania
SCR|Seychellois Rupee|Seychelles|SC|Africa|East Africa
SDG|Sudanese Pound|Sudan|SD|Africa|North Africa
SEK|Swedish Krona|Sweden|SE|Europe|Northern Europe
SGD|Singapore Dollar|Singapore|SG|Asia|Southeast Asia
SHP|Saint Helena Pound|Saint Helena|SH|Africa|West Africa
SLE|Sierra Leonean Leone|Sierra Leone|SL|Africa|West Africa
SOS|Somali Shilling|Somalia|SO|Africa|East Africa
SRD|Surinamese Dollar|Suriname|SR|South America|South America
SSP|South Sudanese Pound|South Sudan|SS|Africa|East Africa
STN|São Tomé and Príncipe Dobra|São Tomé and Príncipe|ST|Africa|Central Africa
SYP|Syrian Pound|Syria|SY|Asia|Middle East
SZL|Eswatini Lilangeni|Eswatini|SZ|Africa|Southern Africa
THB|Thai Baht|Thailand|TH|Asia|Southeast Asia
TJS|Tajikistani Somoni|Tajikistan|TJ|Asia|Central Asia
TMT|Turkmenistan Manat|Turkmenistan|TM|Asia|Central Asia
TND|Tunisian Dinar|Tunisia|TN|Africa|North Africa
TOP|Tongan Paʻanga|Tonga|TO|Oceania|Oceania
TRY|Turkish Lira|Turkey|TR|Asia|Western Asia
TTD|Trinidad and Tobago Dollar|Trinidad and Tobago|TT|North America|Caribbean
TVD|Tuvaluan Dollar|Tuvalu|TV|Oceania|Oceania
TWD|New Taiwan Dollar|Taiwan|TW|Asia|East Asia
TZS|Tanzanian Shilling|Tanzania|TZ|Africa|East Africa
UAH|Ukrainian Hryvnia|Ukraine|UA|Europe|Eastern Europe
UGX|Ugandan Shilling|Uganda|UG|Africa|East Africa
USD|United States Dollar|United States|US|North America|North America
UYU|Uruguayan Peso|Uruguay|UY|South America|South America
UZS|Uzbekistani So'm|Uzbekistan|UZ|Asia|Central Asia
VES|Venezuelan Bolívar Soberano|Venezuela|VE|South America|South America
VND|Vietnamese Đồng|Vietnam|VN|Asia|Southeast Asia
VUV|Vanuatu Vatu|Vanuatu|VU|Oceania|Oceania
WST|Samoan Tālā|Samoa|WS|Oceania|Oceania
XAF|Central African CFA Franc|Cameroon|CM|Africa|Central Africa
XCD|East Caribbean Dollar|Antigua and Barbuda|AG|North America|Caribbean
XDR|Special Drawing Rights|International Monetary Fund|IM|Global|Global
XOF|West African CFA franc|Senegal|SN|Africa|West Africa
XPF|CFP Franc|French Polynesia|PF|Oceania|Oceania
YER|Yemeni Rial|Yemen|YE|Asia|Middle East
ZAR|South African Rand|South Africa|ZA|Africa|Southern Africa
ZMW|Zambian Kwacha|Zambia|ZM|Africa|East Africa
ZWL|Zimbabwean Dollar|Zimbabwe|ZW|Africa|Southern Africa"""

SYMBOLS = {
    "AED": "د.إ", "AFN": "؋", "ALL": "L", "AMD": "֏", "ANG": "ƒ", "AOA": "Kz", "ARS": "$",
    "AUD": "A$", "AWG": "ƒ", "AZN": "₼", "BAM": "KM", "BBD": "$", "BDT": "৳", "BGN": "лв",
    "BHD": ".د.ب", "BIF": "FBu", "BMD": "$", "BND": "$", "BOB": "Bs.", "BRL": "R$", "BSD": "$",
    "BTN": "Nu.", "BWP": "P", "BYN": "Br", "BZD": "$", "CAD": "C$", "CDF": "FC", "CHF": "Fr",
    "CLF": "UF", "CLP": "$", "CNH": "¥", "CNY": "¥", "COP": "$", "CRC": "₡", "CUP": "$",
    "CVE": "$", "CZK": "Kč", "DJF": "Fdj", "DKK": "kr", "DOP": "$", "DZD": "د.ج", "EGP": "£",
    "ERN": "Nfk", "ETB": "Br", "EUR": "€", "FJD": "$", "FKP": "£", "FOK": "kr", "GBP": "£",
    "GEL": "₾", "GGP": "£", "GHS": "₵", "GIP": "£", "GMD": "D", "GNF": "FG", "GTQ": "Q",
    "GYD": "$", "HKD": "$", "HNL": "L", "HRK": "kn", "HTG": "G", "HUF": "Ft", "IDR": "Rp",
    "ILS": "₪", "IMP": "£", "INR": "₹", "IQD": "ع.د", "ISK": "kr", "JEP": "£", "JMD": "$",
    "JOD": "د.ا", "JPY": "¥", "KES": "KSh", "KGS": "с", "KHR": "៛", "KID": "$", "KMF": "CF",
    "KRW": "₩", "KWD": "د.ك", "KYD": "$", "KZT": "₸", "LAK": "₭", "LBP": "ل.ل", "LKR": "Rs",
    "LRD": "$", "LSL": "L", "LYD": "ل.د", "MAD": "د.م.", "MDL": "L", "MGA": "Ar", "MKD": "ден",
    "MMK": "K", "MNT": "₮", "MOP": "MOP$", "MRU": "UM", "MUR": "₨", "MVR": "Rf", "MWK": "MK",
    "MXN": "$", "MYR": "RM", "MZN": "MT", "NAD": "$", "NGN": "₦", "NIO": "C$", "NOK": "kr",
    "NPR": "₨", "NZD": "$", "OMR": "ر.ع.", "PAB": "B/.", "PEN": "S/", "PGK": "K", "PHP": "₱",
    "PKR": "₨", "PLN": "zł", "PYG": "₲", "QAR": "ر.ق", "RON": "lei", "RSD": "дин", "RUB": "₽",
    "RWF": "FRw", "SAR": "ر.س", "SBD": "$", "SCR": "₨", "SDG": "ج.س", "SEK": "kr", "SGD": "$",
    "SHP": "£", "SLE": "Le", "SOS": "Sh", "SRD": "$", "SSP": "£", "STN": "Db", "SYP": "£",
    "SZL": "L", "THB": "฿", "TJS": "ЅМ", "TMT": "m", "TND": "د.ت", "TOP": "T$", "TRY": "₺",
    "TTD": "$", "TVD": "$", "TWD": "NT$", "TZS": "Sh", "UAH": "₴", "UGX": "USh", "USD": "$",
    "UYU": "$", "UZS": "soʻm", "VES": "Bs.", "VND": "₫", "VUV": "Vt", "WST": "T", "XAF": "FCFA",
    "XCD": "$", "XDR": "XDR", "XOF": "CFA", "XPF": "₣", "YER": "﷼", "ZAR": "R", "ZMW": "ZK",
    "ZWL": "$",
}

EXTRA = [
    ("Italy", "IT", "EUR", "Euro", "€", "Europe", "Southern Europe"),
    ("Spain", "ES", "EUR", "Euro", "€", "Europe", "Southern Europe"),
    ("Netherlands", "NL", "EUR", "Euro", "€", "Europe", "Western Europe"),
    ("Belgium", "BE", "EUR", "Euro", "€", "Europe", "Western Europe"),
    ("Austria", "AT", "EUR", "Euro", "€", "Europe", "Central Europe"),
    ("Portugal", "PT", "EUR", "Euro", "€", "Europe", "Southern Europe"),
    ("Ireland", "IE", "EUR", "Euro", "€", "Europe", "Western Europe"),
    ("Finland", "FI", "EUR", "Euro", "€", "Europe", "Northern Europe"),
    ("Greece", "GR", "EUR", "Euro", "€", "Europe", "Southern Europe"),
    ("Luxembourg", "LU", "EUR", "Euro", "€", "Europe", "Western Europe"),
    ("Slovakia", "SK", "EUR", "Euro", "€", "Europe", "Central Europe"),
    ("Slovenia", "SI", "EUR", "Euro", "€", "Europe", "Southern Europe"),
    ("Estonia", "EE", "EUR", "Euro", "€", "Europe", "Northern Europe"),
    ("Latvia", "LV", "EUR", "Euro", "€", "Europe", "Northern Europe"),
    ("Lithuania", "LT", "EUR", "Euro", "€", "Europe", "Northern Europe"),
    ("Cyprus", "CY", "EUR", "Euro", "€", "Europe", "Southern Europe"),
    ("Malta", "MT", "EUR", "Euro", "€", "Europe", "Southern Europe"),
    ("Benin", "BJ", "XOF", "West African CFA franc", "CFA", "Africa", "West Africa"),
    ("Burkina Faso", "BF", "XOF", "West African CFA franc", "CFA", "Africa", "West Africa"),
    ("Côte d'Ivoire", "CI", "XOF", "West African CFA franc", "CFA", "Africa", "West Africa"),
    ("Guinea-Bissau", "GW", "XOF", "West African CFA franc", "CFA", "Africa", "West Africa"),
    ("Mali", "ML", "XOF", "West African CFA franc", "CFA", "Africa", "West Africa"),
    ("Niger", "NE", "XOF", "West African CFA franc", "CFA", "Africa", "West Africa"),
    ("Togo", "TG", "XOF", "West African CFA franc", "CFA", "Africa", "West Africa"),
    ("Chad", "TD", "XAF", "Central African CFA Franc", "FCFA", "Africa", "Central Africa"),
    ("Republic of the Congo", "CG", "XAF", "Central African CFA Franc", "FCFA", "Africa", "Central Africa"),
    ("Equatorial Guinea", "GQ", "XAF", "Central African CFA Franc", "FCFA", "Africa", "Central Africa"),
    ("Gabon", "GA", "XAF", "Central African CFA Franc", "FCFA", "Africa", "Central Africa"),
    ("Central African Republic", "CF", "XAF", "Central African CFA Franc", "FCFA", "Africa", "Central Africa"),
    ("Grenada", "GD", "XCD", "East Caribbean Dollar", "$", "North America", "Caribbean"),
    ("Saint Lucia", "LC", "XCD", "East Caribbean Dollar", "$", "North America", "Caribbean"),
    ("Saint Vincent and the Grenadines", "VC", "XCD", "East Caribbean Dollar", "$", "North America", "Caribbean"),
    ("Dominica", "DM", "XCD", "East Caribbean Dollar", "$", "North America", "Caribbean"),
    ("Saint Kitts and Nevis", "KN", "XCD", "East Caribbean Dollar", "$", "North America", "Caribbean"),
]

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "app" / "data" / "exchangerate_currencies.py"


def main() -> None:
    lines = [
        '"""ExchangeRate-API supported currencies and countries."""',
        "",
        "from __future__ import annotations",
        "",
        "EXCHANGERATE_CURRENCIES: list[dict[str, str]] = [",
    ]
    for row in ENTRIES.strip().splitlines():
        code, name, country, cc, cont, reg = row.split("|")
        sym = SYMBOLS.get(code, "")
        lines.append(
            f'    {{"code": "{code}", "name": "{name}", "country": "{country}", '
            f'"country_code": "{cc}", "continent": "{cont}", "region": "{reg}", "symbol": "{sym}"}},'
        )
    lines.append("]")
    lines.append("")
    lines.append("ADDITIONAL_CURRENCY_COUNTRIES: list[dict[str, str]] = [")
    for name, code, cur, cname, sym, cont, reg in EXTRA:
        lines.append(
            f'    {{"name": "{name}", "code": "{code}", "currency": "{cur}", '
            f'"currency_name": "{cname}", "currency_symbol": "{sym}", '
            f'"continent": "{cont}", "region": "{reg}"}},'
        )
    lines.append("]")
    lines.append("")
    lines.extend(
        [
            'CURRENCY_BY_CODE: dict[str, dict[str, str]] = {c["code"]: c for c in EXCHANGERATE_CURRENCIES}',
            "COUNTRY_BY_CODE: dict[str, dict[str, str]] = {}",
            "for c in EXCHANGERATE_CURRENCIES:",
            "    COUNTRY_BY_CODE.setdefault(c['country_code'], {",
            '        "name": c["country"], "code": c["country_code"], "currency": c["code"],',
            '        "currency_name": c["name"], "currency_symbol": c["symbol"],',
            '        "continent": c["continent"], "region": c["region"],',
            "    })",
            "for c in ADDITIONAL_CURRENCY_COUNTRIES:",
            "    COUNTRY_BY_CODE.setdefault(c['code'], c)",
            "",
            'CURRENCY_TO_COUNTRY: dict[str, str] = {c["code"]: c["country_code"] for c in EXCHANGERATE_CURRENCIES}',
            'SUPPORTED_CURRENCY_CODES: list[str] = [c["code"] for c in EXCHANGERATE_CURRENCIES]',
            "",
        ]
    )
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUT} ({len(ENTRIES.strip().splitlines())} currencies)")


if __name__ == "__main__":
    main()